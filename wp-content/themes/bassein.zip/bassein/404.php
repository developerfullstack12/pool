<?php
/**
 * The template to display the 404 page
 *
 * @package WordPress
 * @subpackage BASSEIN
 * @since BASSEIN 1.0
 */

get_header();

get_template_part( 'content', '404' );

get_footer();
?>